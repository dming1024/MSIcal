# 导入当前目录的.test
from .MSIcal import calMSI,calculateMSI,outMSI  # 此项为必须！必不可少！
__version__ = '1.0'  # 设置版本信息